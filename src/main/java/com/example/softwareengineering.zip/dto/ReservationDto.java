package com.example.softwareengineering.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;

/**
 * 예약 시스템에서 사용되는 Data Transfer Object(DTO) 클래스입니다.
 * 이 클래스는 객실 예약과 관련된 정보를 포함합니다.
 */
@Data // Lombok을 사용하여 getter, setter, toString 등을 자동으로 생성
@Setter
@Getter
public class ReservationDto {
    Long roomId; // 예약하고자 하는 객실의 고유 ID
    String phonenumber; // 예약을 진행하는 학생의 고유 ID
    LocalDateTime startDateTime; // 예약 시작 시간
    LocalDateTime endDateTime; // 예약 종료 시간
}

