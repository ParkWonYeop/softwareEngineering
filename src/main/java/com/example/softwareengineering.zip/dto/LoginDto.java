package com.example.softwareengineering.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * 사용자 로그인 요청 시 사용되는 Data Transfer Object(DTO) 클래스입니다.
 * 사용자의 전화번호와 비밀번호 정보를 포함합니다.
 */
@Data // Lombok을 사용하여 getter, setter, toString 등을 자동으로 생성
@Setter
@Getter
public class LoginDto {
    private String phonenumber; // 사용자 전화번호
    private String password; // 사용자 비밀번호
}
